/* GENERATED CODE - DO NOT MODIFY */
#include "kxusertm.h"


static char stamp[] = "Sat Apr 15 20:06:26 2017";

static KXRMENTRY rms[1] = { 0

};

struct kxGlobalRMTable_t kxGlobalRMTable = { 0, rms, stamp };

