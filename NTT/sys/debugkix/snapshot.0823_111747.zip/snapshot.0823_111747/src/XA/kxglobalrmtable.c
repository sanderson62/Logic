/* GENERATED CODE - DO NOT MODIFY */
#include "kxusertm.h"


static char stamp[] = "Mon Apr 12 13:37:51 2021";

static KXRMENTRY rms[1] = { 0

};

struct kxGlobalRMTable_t kxGlobalRMTable = { 0, rms, stamp };

