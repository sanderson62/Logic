/* GENERATED CODE - DO NOT MODIFY */
#include "kxusertm.h"


static char stamp[] = "Mon Aug 23 14:31:31 2021";

static KXRMENTRY rms[1] = { 0

};

struct kxGlobalRMTable_t kxGlobalRMTable = { 0, rms, stamp };

